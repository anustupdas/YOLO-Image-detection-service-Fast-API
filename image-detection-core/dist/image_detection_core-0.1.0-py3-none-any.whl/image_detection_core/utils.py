def check_number_input(input):
    return len(input)
